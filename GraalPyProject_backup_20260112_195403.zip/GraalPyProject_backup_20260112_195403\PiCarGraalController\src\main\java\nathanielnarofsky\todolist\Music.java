package nathanielnarofsky.todolist;

public class Music {
    //this class will handle music playback on the PiCar
    //this class still needs to be implemented
    //this class will most likely use JavaFX for audio playback

}
