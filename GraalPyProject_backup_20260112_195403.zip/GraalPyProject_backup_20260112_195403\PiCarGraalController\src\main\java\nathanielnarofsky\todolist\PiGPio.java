package nathanielnarofsky.todolist;

public class PiGPio {

    //this class is a wrapper for the required GPIO functions
    //this class still needs to be implemented



    String error = "error";






    public PiGPio() {
        // Constructor implementation
    }

    public void INPUT() {
        // Implementation for setting pin mode to INPUT
    }

    public void OUTPUT() {
        // Implementation for setting pin mode to OUTPUT
    }

    public void ALT0() {
        // Implementation for setting pin mode to ALT0
    }

    public void ALT1() {
        // Implementation for setting pin mode to ALT1
    }

    public void ALT2() {
        // Implementation for setting pin mode to ALT2
    }

    public void ALT3() {
        // Implementation for setting pin mode to ALT3
    }

    public void ALT4() {
        // Implementation for setting pin mode to ALT4
    }

    public void ALT5() {
        // Implementation for setting pin mode to ALT5
    }


    public void PUD_UP() {
        // Implementation for setting pull-up resistor
    }

    public void PUD_DOWN() {
        // Implementation for setting pull-down resistor
    }

    public void PUD_OFF() {
        // Implementation for disabling pull-up/down resistors
    }

    public void EITHER_EDGE() {
        // Implementation for setting edge detection to EITHER_EDGE
    }   

    public void RISING_EDGE() {
        // Implementation for setting edge detection to RISING
    }

    public void FALLING_EDGE() {
        // Implementation for setting edge detection to FALLING
    }



}
