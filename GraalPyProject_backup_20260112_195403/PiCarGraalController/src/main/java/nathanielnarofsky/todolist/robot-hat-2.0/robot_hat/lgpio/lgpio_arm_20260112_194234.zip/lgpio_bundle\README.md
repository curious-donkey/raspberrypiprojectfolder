﻿# LGPIO ARM Compilation Bundle

## Prerequisites on Raspberry Pi:
```bash
sudo apt update
sudo apt install -y build-essential openjdk-11-jdk-headless
```

## Build Instructions:
1. Extract this bundle on your Raspberry Pi
2. Set JAVA_HOME if needed:
   ```bash
   export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-armhf
   ```
3. Run the build script:
   ```bash
   chmod +x build_arm.sh
   ./build_arm.sh
   ```

## Files included:
- lgpio_wrap.c - SWIG-generated C wrapper
- src/ - Original lgpio C source code
- build_arm.sh - Build script for ARM/Linux  
- java/ - Generated Java classes
